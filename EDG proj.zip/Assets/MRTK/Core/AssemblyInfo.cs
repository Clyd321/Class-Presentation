// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
[assembly: System.Reflection.AssemblyVersion("2.7.2.0")]
[assembly: System.Reflection.AssemblyFileVersion("2.7.2.0")]

[assembly: System.Reflection.AssemblyProduct("Microsoft® Mixed Reality Toolkit")]
[assembly: System.Reflection.AssemblyCopyright("Copyright © Microsoft Corporation")]
