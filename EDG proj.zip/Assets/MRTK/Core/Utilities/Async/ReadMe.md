Adapted from https://github.com/svermeulen/Unity3dAsyncAwaitUtil

For details on usage see the associated blog post [here](http://www.stevevermeulen.com/index.php/2017/09/23/using-async-await-in-unity3d-2017/).
